# CrabOS Ultimate

**Um sistema operacional de sites com codigo aberto com NodeJS otimizado para**.

### Setup

1) Abra o arquivo [conf.json](/conf.json)

```json
{"port":"<porta-pricipal>", "publicDir":"/public", "error":"<html-da-pagina-404>"}
```

*modifique ao seu gosto*

2) Digite em seu terminal:

```bash
npm install --no-bin-links
```

3) Instale o [Pm2](https://www.npmjs.com/package/pm2)

4) Digite em seu terminal:

```bash
pm2 start index.js
```

*para desligar o processo:*

```bash
pm2 stop index.js
```

### Ngrok

1) Instale o [ngrok](https://ngrok.com/download)

```bash
snap install ngrok
```

2) Digite:

```bash
ngrok http <porta-principal>
```

*agora seu servidor está online*

### Download

* Versão atual: [Ultimate](https://os.crabs.ml/ultimate/main.zip)

### Api:

*se encontra nas configurações*

`crabos.port` - porta do servidor web.

`crabos.publicDir` - Nome da [pasta principal](/public) dos arquivos html.

`crabos.error` - Define a Página 404 do site.